=================
API Documentation
=================

.. toctree::
   :caption: Table of Contents
   :maxdepth: 2

   api/ta_lib.rst
   
