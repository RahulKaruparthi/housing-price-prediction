============
Data Sources
============


Source ERD
==========

ERD & data dictionary or all sources.

Source validation rules
=======================

Rules to verified on source data such as cardinality, key mismatches, etc..


Source data summary
===================

Reports for quick reference covering data preview, variable summaries, data health etc..

Configurations
==============

Describe Configuration files, Manual inputs & constants to be used in the project.
