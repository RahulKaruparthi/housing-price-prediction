# from . import excel
# from . import ppt
from . import html, table_styles
from .contents import *
from .helpers import (
    create_components,
    format_tables_in_report,
    get_component_in_format,
)
from .lib import create_report
from .table_styles import options, preset_styles, styles
