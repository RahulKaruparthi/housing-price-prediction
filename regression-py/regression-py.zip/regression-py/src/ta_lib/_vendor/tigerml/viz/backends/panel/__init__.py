from .panel import PanelBackend, style_path, tigerml_logo_path, zoom_style_path
