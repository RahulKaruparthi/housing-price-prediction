# Edit the code below...
def func(x):
    output = (x == "male") * 1
    return output
