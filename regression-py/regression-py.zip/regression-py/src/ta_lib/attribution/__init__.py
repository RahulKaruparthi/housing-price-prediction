"""Function to find attribution. Config.csv has to be along with function call statement."""
