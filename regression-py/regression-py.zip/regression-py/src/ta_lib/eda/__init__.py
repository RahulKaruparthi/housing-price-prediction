"""Utility functions for Exploratory Data Analysis (EDA).

This package provides a collection of common analytical and visual tools
used during EDA.
"""
